#!/bin/bash

sudo apt remove -y needrestart
sudo apt update
echo "postfix postfix/mail_type select No configuration" | sudo debconf-set-selections
echo "postfix postfix/main_mailer_type string 'No configuration'" | sudo debconf-set-selection
echo "postfix postfix/mailname string cbr2.ubuntu.local" | sudo debconf-set-selections
echo "postfix postfix/main_mailer_type select No configuration" | sudo debconf-set-selections
echo "libc6 libraries/restart-without-asking boolean true" | sudo debconf-set-selections
sudo apt-get upgrade -y
sudo apt autoremove --purge -y

# Install Build and Development Packages
sudo apt install -y build-essential curl

# Network Security
echo "y" | sudo ufw enable
sudo ufw default deny incoming
sudo ufw reload
sudo ufw allow 22

# Malware Scanners
sudo apt install -y chkrootkit rkhunter lynis checksec clamav clamav-daemon
sudo rkhunter --propupd

sudo systemctl stop clamav-freshclam
sudo freshclam
sudo systemctl enable clamav-freshclam --now

# Kernel Security
cat sysctl-baseline.conf | sudo tee -a /etc/sysctl.conf
sudo sysctl -p
sudo apt install --install-recommends linux-generic -y
sudo cp -f kernel_update.sh "$HOME/"
sudo chmod +x "$HOME/kernel_update.sh"
CRON_JOB="@reboot $HOME/kernel_update.sh"
if ! crontab -l | grep -q "$CRON_JOB"; then
    (crontab -l 2>/dev/null; echo "$CRON_JOB") | crontab -
    echo "Cron bejegyzés hozzáadva."
else
    echo "Cron bejegyzés már létezik."
fi

# Apparmor
sudo apt install -y apparmor-profiles apparmor-profiles-extra
sudo apt install -y libpam-apparmor dh-apparmor apparmor-utils apparmor-notify apparmor-easyprof
sudo systemctl enable --now apparmor
echo "session optional     pam_apparmor.so order=user,group,default" | sudo tee -a /etc/pam.d/su
sudo apparmor_parser -r -T -W /etc/apparmor.d/pam_binaries /etc/apparmor.d/pam_roles

# Entropy
sudo apt install -y rng-tools jitterentropy-rngd
sudo systemctl enable --now jitterentropy

# Filesystem and Integrity Monitoring
sudo apt install -y sxid
sudo find /etc -name sxid.conf -type f -exec sed -i 's/ALWAYS_NOTIFY = "no"/ALWAYS_NOTIFY = "yes"/g' {} +
sudo find /etc -name sxid.conf -type f -exec sed -i 's/LISTALL = "no"/LISTALL = "yes"/g' {} +

sudo touch /var/spool/cron/crontabs/root
echo "0 */1 * * * /usr/bin/sxid --spotcheck -l" | sudo tee -a /var/spool/cron/crontabs/root

sudo apt install aide aide-common -y

sudo cp -f aide.conf /etc/aide/

echo "y" | sudo DEBIAN_FRONTEND=noninteractive aideinit -y

sudo cp -f /var/lib/aide/aide.db{.new,}

echo "*/30 * * * * /usr/bin/aide -c /etc/aide/aide.conf -C" | sudo tee -a /var/spool/cron/crontabs/root

printf "Rebooting the system...."
sleep 3 && sudo reboot
