#!/bin/bash

# Flag file check
FLAG_FILE="/tmp/kernel_cleanup_done"

if [ -f "$FLAG_FILE" ]; then
    echo "A szkript már le lett futtatva. Kilépés..."
    exit 0
fi

# Flag file creation
touch "$FLAG_FILE"

set -e

CURRENT_KERNEL=$(uname -r | sed 's/-generic//')
OLD_KERNELS=$(dpkg --list | grep 'linux-image-[0-9]' | awk '{print $2}' | grep -v "$CURRENT_KERNEL")

for KERNEL in $OLD_KERNELS; do
    sudo apt remove --purge -y "$KERNEL"
done

#Remove unused packages
sudo apt autoremove -y
dpkg --list | grep '^rc' | grep 'linux-image-unsigned' | awk '{print $2}' | xargs sudo apt purge -y
sudo rm -f "$FLAG_FILE"
sudo rm -f /etc/cron.d/kernel_update
crontab -l | grep -v '@reboot /home/ubuntu/kernel_update.sh' | crontab -
sudo apt update
sudo apt upgrade -y
sudo apt autoremove --purge -y
